// Crypto Boss: сервер для игры по сети. Запуск: node server.js
// Зависимостей нет, ничего устанавливать через npm не нужно.
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, 'rooms.json');
const PAGE = path.join(__dirname, 'index.html');
const rooms = new Map(); // код -> {n, mode, seats, v, s, t, clients}

try {
  for (const [c, r] of Object.entries(JSON.parse(fs.readFileSync(DB, 'utf8')))) rooms.set(c, { ...r, clients: new Set() });
} catch (e) {}

let timer = null;
function save() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    const o = {};
    for (const [c, r] of rooms) o[c] = { n: r.n, mode: r.mode, seats: r.seats, v: r.v, s: r.s, t: r.t };
    fs.writeFile(DB, JSON.stringify(o), () => {});
  }, 500);
}
const pub = r => ({ n: r.n, mode: r.mode, seats: r.seats, v: r.v, s: r.s });
function send(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); }
function body(req) {
  return new Promise((ok, no) => {
    let b = '';
    req.on('data', d => { b += d; if (b.length > 300000) { no(new Error('big')); req.destroy(); } });
    req.on('end', () => { try { ok(JSON.parse(b || '{}')); } catch (e) { no(e); } });
  });
}
function broadcast(r) {
  const m = 'data: ' + JSON.stringify(pub(r)) + '\n\n';
  for (const c of r.clients) c.write(m);
}
const okUid = u => typeof u === 'string' && u.length > 0 && u.length <= 64;
const okCode = c => typeof c === 'string' && /^[A-Z]{4}$/.test(c);
// Чей сейчас ход (на аукционе ходит тот, чья очередь ставить)
function actor(s) {
  try { const g = JSON.parse(s); return g.phase === 'auction' && g.auc ? g.auc.i : g.cur; } catch (e) { return -1; }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    fs.readFile(PAGE, (e, d) => {
      if (e) { res.writeHead(500); return res.end('index.html не найден рядом с server.js'); }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
      res.end(d);
    });
    return;
  }
  // Скачивание файлов с другого устройства: http://адрес:3000/download
  const FILES = { 'index.html': 'text/html; charset=utf-8', 'server.js': 'text/javascript; charset=utf-8', 'README.md': 'text/markdown; charset=utf-8' };
  if (req.method === 'GET' && url.pathname === '/download') {
    const links = Object.keys(FILES).map(f => '<p><a href="/download/' + f + '">Скачать ' + f + '</a></p>').join('');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Crypto Boss: скачать</title><body style="font:18px sans-serif;background:#1b1b1d;color:#ededed;padding:24px"><h2>Crypto Boss: скачать файлы</h2>' + links.replace(/<a /g, '<a style="color:#3db89e" ') + '<p style="color:#9a9aa0">Игра из скачанного index.html работает только на одном устройстве. Для игры по сети открывай адрес сервера.</p></body>');
  }
  if (req.method === 'GET' && url.pathname.startsWith('/download/')) {
    const f = decodeURIComponent(url.pathname.slice(10));
    if (!Object.prototype.hasOwnProperty.call(FILES, f)) { res.writeHead(404); return res.end(); }
    return fs.readFile(path.join(__dirname, f), (e, d) => {
      if (e) { res.writeHead(404); return res.end('Файл не найден'); }
      res.writeHead(200, { 'Content-Type': FILES[f], 'Content-Disposition': 'attachment; filename="' + f + '"' });
      res.end(d);
    });
  }
  if (req.method === 'GET' && url.pathname === '/api/events') {
    const r = rooms.get(url.searchParams.get('code')), uid = url.searchParams.get('uid');
    if (!r || !r.seats.includes(uid)) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write('data: ' + JSON.stringify(pub(r)) + '\n\n');
    r.clients.add(res);
    const hb = setInterval(() => res.write(': hb\n\n'), 25000);
    req.on('close', () => { clearInterval(hb); r.clients.delete(res); });
    return;
  }
  if (req.method === 'POST' && url.pathname.startsWith('/api/')) {
    let b;
    try { b = await body(req); } catch (e) { return send(res, 400, { error: 'Плохой запрос' }); }
    if (!okUid(b.uid)) return send(res, 400, { error: 'Нет идентификатора игрока' });
    if (url.pathname === '/api/create') {
      const n = b.n, mode = b.mode;
      if (![2, 3, 4].includes(n) || !['nodes', 'rich'].includes(mode)) return send(res, 400, { error: 'Неверные настройки' });
      let code;
      do { code = Array.from({ length: 4 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random() * 23)]).join(''); } while (rooms.has(code));
      rooms.set(code, { n, mode, seats: [b.uid].concat(Array(n - 1).fill('')), v: 0, s: '', t: Date.now(), clients: new Set() });
      save();
      return send(res, 200, { code });
    }
    if (!okCode(b.code)) return send(res, 400, { error: 'Неверный код' });
    const r = rooms.get(b.code);
    if (!r) return send(res, 404, { error: 'Комната с таким кодом не найдена' });
    r.t = Date.now();
    if (url.pathname === '/api/join') {
      let i = r.seats.indexOf(b.uid);
      if (i < 0) {
        i = r.seats.indexOf('');
        if (i < 0) return send(res, 409, { error: 'В комнате нет свободных мест' });
        r.seats[i] = b.uid; save(); broadcast(r);
      }
      return send(res, 200, { seat: i });
    }
    if (url.pathname === '/api/state') {
      const i = r.seats.indexOf(b.uid);
      if (i < 0) return send(res, 403, { error: 'Ты не в этой комнате' });
      if (typeof b.s !== 'string' || b.v !== r.v + 1) return send(res, 409, { error: 'Устаревшее состояние' });
      const allowed = r.s ? actor(r.s) === i : (i === 0 && r.seats.every(Boolean));
      if (!allowed) return send(res, 403, { error: 'Сейчас ходит другой игрок' });
      r.s = b.s; r.v = b.v; save(); broadcast(r);
      return send(res, 200, { ok: true });
    }
  }
  res.writeHead(404); res.end();
});

setInterval(() => {
  const old = Date.now() - 48 * 3600 * 1000;
  for (const [c, r] of rooms) if (r.t < old) { rooms.delete(c); save(); }
}, 3600 * 1000);

server.listen(PORT, '0.0.0.0', () => {
  console.log('Crypto Boss запущен: http://localhost:' + PORT);
  console.log('Скачать файлы: http://localhost:' + PORT + '/download');
  for (const l of Object.values(os.networkInterfaces()))
    for (const a of l) if (a.family === 'IPv4' && !a.internal) console.log('В вашей сети: http://' + a.address + ':' + PORT);
});
